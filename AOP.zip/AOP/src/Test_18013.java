

public class Test_18013
{
	public static void main(String[] args)
	{
//		System.out.println("in main");
		MyChannel_18013 s  = new MyChannel_18013();
		MyChannel_18013 s1 = new MyChannel_18013();
		s.open();s.read();s.read();s.close();s.open();s1.open();
//		s1.read();
//		s.close();
		s.close();
		s.read();
		
	}
}