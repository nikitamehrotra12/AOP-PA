
class MyChannel_18013 {

	public void open(){
		System.out.println("Channel is opened");
	}
	public void read(){
		System.out.println("Channel is reading");
	}
	public void write(){
		System.out.println("Channel is writing");
	}
	public void close(){
		System.out.println("Channel is closed");
	}

}

