

public class ChannelException_18013 extends RuntimeException
{
	public ChannelException_18013(String s) 
	{
		if(s.equals("Channel has to be opened before it is closed.")) {
		System.out.println("channel has to be opened before it is closed");
		}
		else if(s.equals("The channel has to be closed after it is opened.")) {
		System.out.println("The channel has to be closed after it is opened.");
		}
		else if(s.equals("Reading from and writing to the channel is only allowed after opening and before the closing of the channel.")) {
			System.out.println("Reading from and writing to the channel is only allowed after opening and before the closing of the channel.");
		}
		else if(s.equals("An opened channel should not be reopened.")) {
			System.out.println("An opened channel should not be reopened.");
		}
		else if(s.equals("A closed channel should not be reclosed.")) {
			System.out.println("A closed channel should not be reclosed.");
		}
		else {
			System.out.println(s);
		}
	}
}